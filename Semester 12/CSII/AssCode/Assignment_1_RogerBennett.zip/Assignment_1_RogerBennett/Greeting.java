public class Greeting {
    public static void main (String[] args) {
        System.out.println("I do not know why you would want us to not print 'Hello, World'. It is a classic!!");
    }
}
